(() => {
  const STORE_KEY = 'campusmate-v1';
  const today = new Date();
  const localDate = (d = new Date()) => { const x = new Date(d); x.setMinutes(x.getMinutes() - x.getTimezoneOffset()); return x.toISOString().slice(0, 10); };
  const fresh = { assignments: [], subjects: [], sessions: [], notes: [], activity: [], theme: 'light' };
  let data;
  try { data = { ...fresh, ...JSON.parse(localStorage.getItem(STORE_KEY) || '{}') }; } catch { data = { ...fresh }; }
  data.assignments ||= []; data.subjects ||= []; data.sessions ||= []; data.notes ||= []; data.activity ||= [];
  let timer = { remaining: 25 * 60, interval: null, running: false, paused: false };
  let toastTimeout;
  const $ = (s, root = document) => root.querySelector(s);
  const esc = (s = '') => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const save = () => localStorage.setItem(STORE_KEY, JSON.stringify(data));
  const log = (text, icon = '✦') => { data.activity.unshift({ text, icon, at: Date.now() }); data.activity = data.activity.slice(0, 9); save(); renderActivity(); };
  const toast = msg => { const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toastTimeout); toastTimeout = setTimeout(() => el.classList.remove('show'), 2600); };
  const subjectNames = () => data.subjects.map(s => s.name);
  const empty = (icon, title, copy, action, label) => `<div class="empty-state"><span class="empty-icon">${icon}</span><strong>${title}</strong><p>${copy}</p>${action ? `<button data-open="${action}">${label}</button>` : ''}</div>`;
  const dateText = date => { if (!date) return 'No due date'; const diff = Math.round((new Date(`${date}T00:00:00`) - new Date(`${localDate()}T00:00:00`)) / 86400000); if (diff < 0) return `${Math.abs(diff)}d overdue`; if (diff === 0) return 'Due today'; if (diff === 1) return 'Due tomorrow'; return `Due ${new Date(`${date}T00:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}`; };
  const isOverdue = a => !a.completed && a.dueDate && a.dueDate < localDate();
  function renderAssignments() {
    const q = ($('#assignmentSearch').value || '').trim().toLowerCase(); const filter = $('#assignmentFilter').value;
    const list = [...data.assignments].sort((a, b) => (a.completed - b.completed) || (a.dueDate || '9999').localeCompare(b.dueDate || '9999'));
    const found = list.filter(a => { const matches = `${a.title} ${a.subject}`.toLowerCase().includes(q); return matches && (filter === 'all' || filter === 'pending' && !a.completed || filter === 'completed' && a.completed || filter === 'overdue' && isOverdue(a)); });
    $('#assignmentList').innerHTML = found.length ? found.map(a => `<div class="assignment-row ${a.completed ? 'is-complete' : ''}"><button class="assignment-check" data-complete="${a.id}" aria-label="${a.completed ? 'Mark pending' : 'Mark complete'}">${a.completed ? '✓' : ''}</button><div class="assignment-main"><span class="assignment-title">${esc(a.title)}</span><div class="assignment-meta"><span class="subject-tag">${esc(a.subject || 'General')}</span><span class="priority-mark priority-${esc(a.priority)}"></span><span>${esc(a.priority)} priority</span></div></div><span class="assignment-due ${isOverdue(a) ? 'overdue' : ''}">${dateText(a.dueDate)}</span><button class="row-delete" data-delete-assignment="${a.id}" aria-label="Delete ${esc(a.title)}">×</button></div>`).join('') : empty(q || filter !== 'all' ? '⌕' : '✓', q || filter !== 'all' ? 'No matching assignments' : 'Nothing on your list yet', q || filter !== 'all' ? 'Try another search or filter.' : 'Add an assignment and keep your deadlines in view.', q || filter !== 'all' ? '' : 'assignmentModal', q || filter !== 'all' ? '' : '＋ Add assignment');
    const pending = data.assignments.filter(a => !a.completed); $('#navPending').textContent = pending.length;
  }
  function renderStats() {
    const total = data.assignments.length, complete = data.assignments.filter(a => a.completed).length, pending = total - complete, overdue = data.assignments.filter(isOverdue).length;
    $('#statTotal').textContent = total; $('#statPending').textContent = pending; $('#overdueSummary').textContent = `${overdue} overdue`;
    $('#statProgress').innerHTML = `${total ? Math.round(complete / total * 100) : 0}<span class="unit">%</span>`; $('#progressBar').style.width = `${total ? complete / total * 100 : 0}%`;
    const study = data.sessions.filter(s => s.date === localDate() && s.completed).reduce((n, s) => n + Number(s.duration || 0), 0); $('#statStudy').innerHTML = `${study}<span class="unit"> min</span>`;
  }
  function renderSubjects() {
    $('#subjectList').innerHTML = data.subjects.length ? data.subjects.map(s => `<article class="subject-card"><span class="subject-initial">${esc((s.name || '?').slice(0, 1).toUpperCase())}</span><div class="subject-copy"><strong>${esc(s.name)}</strong><small>${esc(s.teacher || 'Teacher not added')} · target ${Number(s.target) || 75}%</small></div><span class="subject-credits">${Number(s.credits) || 0} cr</span><button class="delete-subject" data-delete-subject="${s.id}" aria-label="Delete ${esc(s.name)}">×</button></article>`).join('') : empty('◫', 'Your subjects will live here', 'Add a class to organize assignments and attendance by subject.', 'subjectModal', '＋ Add your first subject');
    $('#attendanceList').innerHTML = data.subjects.length ? data.subjects.map(s => attendanceCard(s)).join('') : empty('◷', 'No attendance to track yet', 'Add subjects first, then record conducted and attended classes.', 'subjectModal', '＋ Add a subject');
  }
  function attendanceCard(s) {
    const held = Math.max(0, Number(s.held) || 0), attended = Math.max(0, Math.min(held, Number(s.attended) || 0)), pct = held ? attended / held * 100 : 0, target = Math.max(1, Math.min(100, Number(s.target) || 75));
    const need = Math.max(0, Math.ceil((target * held - 100 * attended) / (100 - target)));
    const canMiss = held > 0 && (attended / (held + 1) * 100) >= target;
    const message = held === 0 ? 'Enter class totals to see your attendance plan.' : pct >= target ? `On track. ${canMiss ? 'You can miss 1 class and stay at or above target.' : `Attend ${need || 1} more ${need === 1 ? 'class' : 'classes'} to build a buffer.`}` : `Attend ${need} ${need === 1 ? 'class' : 'classes'} consecutively to reach ${target}%. You can't safely miss the next class.`;
    return `<article class="attendance-card"><div class="attendance-head"><strong>${esc(s.name)}</strong><span class="attendance-percent ${pct >= target ? 'good' : 'low'}">${held ? `${pct.toFixed(1)}%` : '—'}</span></div><div class="attendance-track"><span class="${pct >= target ? '' : 'low'}" style="width:${Math.min(100, pct)}%"></span></div><div class="attendance-controls"><label>Classes conducted<input type="number" min="0" data-attendance="${s.id}" data-field="held" value="${held}"></label><label>Classes attended<input type="number" min="0" max="${held}" data-attendance="${s.id}" data-field="attended" value="${attended}"></label></div><p class="attendance-result">Target: <strong>${target}%</strong> · ${message}</p></article>`;
  }
  function renderSessions() {
    const sessions = data.sessions.filter(s => s.date === localDate()).sort((a, b) => (a.completed - b.completed));
    $('#todaySessionCount').textContent = sessions.length; $('#sessionSummaryTitle').textContent = sessions.length ? `${sessions.filter(s => s.completed).length} of ${sessions.length} completed` : 'Your focus, your pace'; $('#sessionSummaryText').textContent = sessions.length ? `${sessions.reduce((n, s) => n + Number(s.duration || 0), 0)} planned minutes today` : 'Add a study session to shape your day.';
    $('#todaySessions').innerHTML = sessions.length ? sessions.map(s => `<div class="session-item ${s.completed ? 'done' : ''}"><span class="session-time-dot"></span><div class="session-info"><strong>${esc(s.subject)}${s.topic ? ` · ${esc(s.topic)}` : ''}</strong><small>${Number(s.duration)} min${s.date ? ` · ${s.date === localDate() ? 'Today' : esc(s.date)}` : ''}</small></div><button class="session-complete" data-complete-session="${s.id}">${s.completed ? '✓ Done' : 'Mark done'}</button></div>`).join('') : empty('◴', 'A clear schedule starts here', 'Plan a focused session for today and protect the time.', 'sessionModal', '＋ Plan a session');
  }
  function renderActivity() {
    $('#activityList').innerHTML = data.activity.length ? data.activity.slice(0, 3).map(a => `<div class="activity-item"><span class="activity-mark">${esc(a.icon)}</span><div><p>${esc(a.text)}</p><small>${new Date(a.at).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</small></div></div>`).join('') : empty('✦', 'Your activity will appear here', 'Completing work and planning sessions will build your activity timeline.');
  }
  function renderNotes() {
    $('#notesList').innerHTML = data.notes.length ? data.notes.map(n => `<article class="note-card"><span class="note-card-icon">✎</span><div><strong>${esc(n.title)}</strong><p>${esc(n.body)}</p><small>${esc(n.subject)}${n.updated ? ` · ${esc(n.updated)}` : ''}</small></div></article>`).join('') : empty('✎', 'No notes saved yet', 'Your study reminders and quick references will appear here when available.');
  }
  function updateTheme() { document.body.dataset.theme = data.theme; document.querySelector('meta[name="theme-color"]').content = data.theme === 'dark' ? '#111622' : '#f4f6fa'; }
  function render() { renderAssignments(); renderStats(); renderSubjects(); renderSessions(); renderActivity(); renderNotes(); updateTheme(); }
  const modalDefs = {
    assignmentModal: { title: 'Add assignment', copy: 'Keep your next deadline in sight.', fields: `<div class="form-field"><label for="fTitle">Assignment title</label><input id="fTitle" name="title" placeholder="e.g. Research paper draft" required maxlength="100"></div><div class="form-grid"><div class="form-field"><label for="fSubject">Subject</label><input id="fSubject" name="subject" list="subjectOptions" placeholder="e.g. Data structures" required><datalist id="subjectOptions">${subjectNames().map(n => `<option value="${esc(n)}">`).join('')}</datalist></div><div class="form-field"><label for="fDue">Due date</label><input id="fDue" type="date" name="dueDate" required></div></div><div class="form-field"><label for="fPriority">Priority</label><select id="fPriority" name="priority"><option value="medium">Medium</option><option value="high">High</option><option value="low">Low</option></select></div>`, submit: 'Save assignment' },
    subjectModal: { title: 'Add subject', copy: 'Set up a class to connect your academic details.', fields: `<div class="form-field"><label for="fName">Subject name</label><input id="fName" name="name" placeholder="e.g. Human Computer Interaction" required maxlength="80"></div><div class="form-grid"><div class="form-field"><label for="fTeacher">Teacher name</label><input id="fTeacher" name="teacher" placeholder="Optional"></div><div class="form-field"><label for="fCredits">Credits</label><input id="fCredits" type="number" min="0" max="30" name="credits" value="3"></div></div><div class="form-field"><label for="fTarget">Target attendance (%)</label><input id="fTarget" type="number" min="1" max="100" name="target" value="75" required></div>`, submit: 'Save subject' },
    sessionModal: { title: 'Plan a study session', copy: 'Choose a subject, set a focus, and make time for it.', fields: `<div class="form-grid"><div class="form-field"><label for="fSessionSubject">Subject</label><input id="fSessionSubject" name="subject" list="sessionSubjectOptions" placeholder="e.g. Statistics" required><datalist id="sessionSubjectOptions">${subjectNames().map(n => `<option value="${esc(n)}">`).join('')}</datalist></div><div class="form-field"><label for="fDuration">Duration (minutes)</label><input id="fDuration" type="number" min="5" max="600" name="duration" value="45" required></div></div><div class="form-field"><label for="fTopic">Topic</label><input id="fTopic" name="topic" placeholder="e.g. Week 4 revision" maxlength="100"></div><div class="form-field"><label for="fDate">Date</label><input id="fDate" type="date" name="date" value="${localDate()}" required></div>`, submit: 'Add study session' }
  };
  function openModal(key) { const def = modalDefs[key]; if (!def) return; $('#modalTitle').textContent = def.title; $('#modalCopy').textContent = def.copy; $('#modalForm').innerHTML = `${def.fields}<button class="button button-primary form-submit" type="submit">${def.submit}</button>`; $('#modalBackdrop').hidden = false; document.body.style.overflow = 'hidden'; setTimeout(() => $('#modalForm input')?.focus(), 40); $('#modalForm').dataset.kind = key; }
  function closeModal() { $('#modalBackdrop').hidden = true; document.body.style.overflow = ''; }
  $('#modalForm').addEventListener('submit', e => {
    e.preventDefault(); const f = new FormData(e.currentTarget); const kind = e.currentTarget.dataset.kind;
    if (kind === 'assignmentModal') { data.assignments.push({ id: crypto.randomUUID(), title: f.get('title').trim(), subject: f.get('subject').trim(), dueDate: f.get('dueDate'), priority: f.get('priority'), completed: false }); log(`Added assignment: ${f.get('title').trim()}`, '▤'); }
    if (kind === 'subjectModal') { const name = f.get('name').trim(); if (data.subjects.some(s => s.name.toLowerCase() === name.toLowerCase())) { toast('That subject is already in your list.'); return; } data.subjects.push({ id: crypto.randomUUID(), name, teacher: f.get('teacher').trim(), credits: Number(f.get('credits')), target: Number(f.get('target')), held: 0, attended: 0 }); log(`Added subject: ${name}`, '◫'); }
    if (kind === 'sessionModal') { data.sessions.push({ id: crypto.randomUUID(), subject: f.get('subject').trim(), topic: f.get('topic').trim(), duration: Number(f.get('duration')), date: f.get('date'), completed: false }); log(`Planned a ${f.get('duration')} min session for ${f.get('subject').trim()}`, '◴'); }
    save(); closeModal(); render(); toast('Saved to your workspace.');
  });
  document.addEventListener('click', e => {
    const opener = e.target.closest('[data-open]'); if (opener) openModal(opener.dataset.open);
    if (e.target.closest('#modalClose') || e.target.id === 'modalBackdrop') closeModal();
    const done = e.target.closest('[data-complete]'); if (done) { const a = data.assignments.find(x => x.id === done.dataset.complete); if (a) { a.completed = !a.completed; log(`${a.completed ? 'Completed' : 'Reopened'}: ${a.title}`, a.completed ? '✓' : '↺'); save(); render(); } }
    const del = e.target.closest('[data-delete-assignment]'); if (del) { const a = data.assignments.find(x => x.id === del.dataset.deleteAssignment); data.assignments = data.assignments.filter(x => x.id !== del.dataset.deleteAssignment); if (a) log(`Deleted assignment: ${a.title}`, '×'); save(); render(); toast('Assignment deleted.'); }
    const sd = e.target.closest('[data-delete-subject]'); if (sd) { const s = data.subjects.find(x => x.id === sd.dataset.deleteSubject); data.subjects = data.subjects.filter(x => x.id !== sd.dataset.deleteSubject); if (s) log(`Removed subject: ${s.name}`, '×'); save(); render(); }
    const sessionDone = e.target.closest('[data-complete-session]'); if (sessionDone) { const s = data.sessions.find(x => x.id === sessionDone.dataset.completeSession); if (s) { s.completed = !s.completed; log(`${s.completed ? 'Completed' : 'Reopened'} study session: ${s.subject}`, '◴'); save(); render(); } }
    if (e.target.closest('#themeToggle, #themeToggleTop')) { data.theme = data.theme === 'dark' ? 'light' : 'dark'; save(); updateTheme(); }
  });
  $('#assignmentSearch').addEventListener('input', renderAssignments); $('#assignmentFilter').addEventListener('change', renderAssignments);
  document.addEventListener('input', e => { const inp = e.target.closest('[data-attendance]'); if (!inp) return; const s = data.subjects.find(x => x.id === inp.dataset.attendance); if (!s) return; s[inp.dataset.field] = Math.max(0, Number(inp.value) || 0); if (s.attended > s.held) s.attended = s.held; save(); renderSubjects(); });
  document.addEventListener('click', e => { const nav = e.target.closest('.nav-link'); if (nav) { document.querySelectorAll('.nav-link').forEach(x => x.classList.toggle('active', x === nav)); $('#currentPage').textContent = nav.querySelector('span:nth-child(2)').textContent; } });
  $('#modalForm'); document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modalBackdrop').hidden) closeModal(); });
  $('#todayLabel').textContent = today.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  function timerDisplay() { const m = Math.floor(timer.remaining / 60), s = timer.remaining % 60; $('#timerDisplay').textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`; }
  function startTimer() { if (timer.running) return; if (!timer.paused) timer.remaining = Math.max(1, Number($('#timerMinutes').value) || 25) * 60; timer.running = true; timer.paused = false; $('#timerStart').hidden = true; $('#timerPause').hidden = false; $('#timerState').textContent = 'Stay with one thing at a time'; timer.interval = setInterval(() => { timer.remaining--; timerDisplay(); if (timer.remaining <= 0) { clearInterval(timer.interval); timer.running = false; timer.paused = false; $('#timerStart').hidden = false; $('#timerPause').hidden = true; $('#timerState').textContent = 'Focus session complete'; toast('Focus session complete. Take a short break.'); } }, 1000); }
  $('#timerStart').addEventListener('click', startTimer); $('#timerPause').addEventListener('click', () => { if (timer.running) { clearInterval(timer.interval); timer.running = false; timer.paused = true; $('#timerStart').hidden = false; $('#timerStart').textContent = 'Resume'; $('#timerPause').hidden = true; $('#timerState').textContent = 'Paused'; } });
  $('#timerReset').addEventListener('click', () => { clearInterval(timer.interval); timer.running = false; timer.paused = false; timer.remaining = Math.max(1, Number($('#timerMinutes').value) || 25) * 60; $('#timerStart').hidden = false; $('#timerStart').textContent = 'Start focus'; $('#timerPause').hidden = true; $('#timerState').textContent = 'Ready when you are'; timerDisplay(); });
  $('#timerMinutes').addEventListener('change', () => { if (!timer.running) { timer.paused = false; $('#timerStart').textContent = 'Start focus'; timer.remaining = Math.max(1, Number($('#timerMinutes').value) || 25) * 60; timerDisplay(); } });
  const cgpaRows = $('#cgpaRows'); function addCgpaRow() { const row = document.createElement('div'); row.className = 'cgpa-row'; row.innerHTML = '<input aria-label="Subject name" placeholder="Subject"><input aria-label="Grade points" type="number" min="0" max="10" step="0.1" placeholder="Grade / 10"><input aria-label="Credits" type="number" min="0.1" max="30" step="0.1" placeholder="Credits"><button class="remove-cgpa" type="button" aria-label="Remove row">×</button>'; cgpaRows.append(row); }
  addCgpaRow(); addCgpaRow(); $('#addCgpaRow').addEventListener('click', addCgpaRow); cgpaRows.addEventListener('click', e => { if (e.target.closest('.remove-cgpa') && cgpaRows.children.length > 1) e.target.closest('.cgpa-row').remove(); });
  $('#cgpaForm').addEventListener('submit', e => { e.preventDefault(); let points = 0, credits = 0; [...cgpaRows.children].forEach(row => { const inputs = row.querySelectorAll('input'), grade = Number(inputs[1].value), credit = Number(inputs[2].value); if (inputs[1].value !== '' && credit > 0 && grade >= 0 && grade <= 10) { points += grade * credit; credits += credit; } }); if (!credits) { toast('Enter at least one valid grade and credit value.'); return; } const result = (points / credits).toFixed(2); $('#cgpaResult').textContent = result; $('#cgpaHint').textContent = `Weighted average across ${credits} credits`; log(`Calculated estimated CGPA: ${result}`, '◎'); });
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  $('#voiceButton').addEventListener('click', () => {
    if (!SR) { toast('Voice input is not supported in this browser.'); $('#voiceStatus').textContent = 'Voice input unavailable'; return; }
    const recognition = new SR(); recognition.lang = navigator.language || 'en-US'; recognition.interimResults = false; recognition.maxAlternatives = 1;
    $('#voiceStatus').textContent = 'Listening…'; $('#voiceButton').classList.add('listening');
    recognition.onresult = event => { const phrase = event.results[0][0].transcript.toLowerCase(); $('#voiceStatus').textContent = `“${phrase}”`; handleVoice(phrase); };
    recognition.onerror = () => { $('#voiceStatus').textContent = 'Could not hear that. Try again.'; toast('Voice input did not work. Please try again.'); };
    recognition.onend = () => $('#voiceButton').classList.remove('listening'); recognition.start();
  });
  function handleVoice(text) {
    if (/add (an )?assignment/.test(text)) return openModal('assignmentModal');
    if (/add (a )?subject/.test(text)) return openModal('subjectModal');
    if (/plan (a )?(study )?session|add (a )?session/.test(text)) return openModal('sessionModal');
    if (/show (my )?assignments|go to assignments/.test(text)) { location.hash = 'assignments'; return; }
    if (/show (my )?attendance|go to attendance/.test(text)) { location.hash = 'attendance'; return; }
    if (/show (my )?subjects|go to subjects/.test(text)) { location.hash = 'subjects'; return; }
    if (/start (the )?(focus )?timer/.test(text)) { startTimer(); return; }
    if (/dark mode/.test(text)) { data.theme = 'dark'; save(); updateTheme(); return toast('Dark theme enabled.'); }
    if (/light mode/.test(text)) { data.theme = 'light'; save(); updateTheme(); return toast('Light theme enabled.'); }
    toast('Try “add an assignment”, “show attendance”, or “start the focus timer”.');
  }

  // BEGIN OPTIONAL DEMO DATA MODULE. Remove this block and the matching Demo data
  // controls section in index.html before production deployment.
  const CampusMateDemo = (() => {
    const shiftDate = days => { const d = new Date(); d.setDate(d.getDate() + days); return localDate(d); };
    const removeSeeded = () => {
      const ids = data.demoDataIds;
      if (!ids) return;
      for (const key of ['subjects', 'assignments', 'sessions', 'notes']) {
        const seeded = new Set(ids[key] || []);
        data[key] = data[key].filter(item => !seeded.has(item.id));
      }
      delete data.demoDataIds;
    };
    const seed = () => {
      removeSeeded();
      const subjects = [
        { id: crypto.randomUUID(), name: 'Human Computer Interaction', teacher: 'Dr. Ananya Rao', credits: 4, target: 75, held: 28, attended: 24 },
        { id: crypto.randomUUID(), name: 'Data Structures', teacher: 'Prof. K. Mehta', credits: 4, target: 75, held: 32, attended: 23 },
        { id: crypto.randomUUID(), name: 'Discrete Mathematics', teacher: 'Dr. Farah Khan', credits: 3, target: 80, held: 25, attended: 22 }
      ];
      const assignments = [
        { title: 'Usability evaluation report', subject: subjects[0].name, dueDate: shiftDate(2), priority: 'high', completed: false },
        { title: 'Binary search tree implementation', subject: subjects[1].name, dueDate: shiftDate(5), priority: 'medium', completed: false },
        { title: 'Graph theory problem set', subject: subjects[2].name, dueDate: shiftDate(-1), priority: 'high', completed: false },
        { title: 'Heuristic analysis worksheet', subject: subjects[0].name, dueDate: shiftDate(-3), priority: 'low', completed: true }
      ].map(item => ({ ...item, id: crypto.randomUUID() }));
      const sessions = [
        { subject: subjects[1].name, topic: 'Tree traversal practice', duration: 45, date: localDate(), completed: true },
        { subject: subjects[0].name, topic: 'Review evaluation notes', duration: 35, date: localDate(), completed: false },
        { subject: subjects[2].name, topic: 'Relations and functions', duration: 40, date: shiftDate(1), completed: false }
      ].map(item => ({ ...item, id: crypto.randomUUID() }));
      const notes = [
        { title: 'HCI · usability review', subject: subjects[0].name, body: 'Check the interface against visibility, consistency, and error-prevention heuristics. Include one concrete example for each finding.', updated: 'Lecture 6' },
        { title: 'Data structures · BST reminder', subject: subjects[1].name, body: 'In-order traversal of a binary search tree visits keys in sorted order. Remember to discuss the worst-case height when the tree is skewed.', updated: 'Revision note' },
        { title: 'Discrete math · induction', subject: subjects[2].name, body: 'State the base case, assume the claim for k, then prove it for k + 1. Make the induction hypothesis explicit before simplifying.', updated: 'Week 5' }
      ].map(item => ({ ...item, id: crypto.randomUUID() }));
      data.subjects.push(...subjects); data.assignments.push(...assignments); data.sessions.push(...sessions); data.notes.push(...notes);
      data.demoDataIds = { subjects: subjects.map(x => x.id), assignments: assignments.map(x => x.id), sessions: sessions.map(x => x.id), notes: notes.map(x => x.id) };
      log('Loaded the CampusMate sample workspace', '✦'); save(); render(); toast('Sample subjects, assignments, attendance, sessions, and notes loaded.');
    };
    const clear = () => { if (!data.demoDataIds) return toast('There is no demo data to clear.'); removeSeeded(); save(); render(); toast('Sample workspace data cleared.'); };
    return { seed, clear };
  })();
  window.CampusMateDemo = CampusMateDemo;
  $('#loadDemoData').addEventListener('click', CampusMateDemo.seed);
  $('#clearDemoData').addEventListener('click', CampusMateDemo.clear);
  // END OPTIONAL DEMO DATA MODULE.

  render(); timerDisplay();
})();
