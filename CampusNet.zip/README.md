# CampusNet — CampusMate

CampusMate is a frontend-only student productivity dashboard built to help university students keep academic tasks, classes, attendance, and study time organized in one calm workspace.

## Problem statement

Students often balance deadlines, course details, attendance thresholds, and independent study across separate tools. CampusMate brings these everyday planning tasks together and makes progress easy to review without an account or server.

## Key features

- Dashboard statistics for total, pending, completed, and overdue assignments, study minutes today, and assignment completion progress.
- Assignment creation with title, subject, due date, and priority; complete/delete actions; status filters; and title/subject search.
- Subject cards with teacher, credit, and attendance target details.
- Attendance entry by subject with percentage, target comparison, consecutive classes required to reach target, and a safe-to-miss-next-class calculation.
- Study sessions with subject, topic, date, duration, and a mark-complete action. Today's sessions and completed study minutes appear on the dashboard.
- Configurable focus timer with start, pause, resume, and reset controls.
- Credit-weighted CGPA estimate on a 10-point scale.
- Light and dark themes, responsive navigation, empty states, activity history, and accessible form labels.
- Optional voice commands for common navigation and actions.

## Voice command functionality

The voice assistant uses the browser's built-in Web Speech API when available. Select **Voice assistant**, allow microphone access, and speak a supported phrase, for example:

- “Add an assignment”
- “Add a subject”
- “Plan a study session”
- “Show attendance”
- “Show assignments”
- “Start the focus timer”
- “Dark mode” / “Light mode”

Speech recognition support and permission behavior depend on the browser. The rest of the app works without microphone access. Voice input is handled by the browser API; this project does not include a backend voice service.

## Local storage

CampusMate saves assignments, subjects, attendance counts, sessions, activity entries, and the selected theme in the browser's `localStorage` under the `campusmate-v1` key. Data stays in the current browser profile on the current device. Clearing site data or using another browser/profile removes or separates that data. No server or account is involved.

## Technology stack

- Semantic HTML5
- CSS with reusable custom properties and responsive media queries
- Plain JavaScript (ES2020+)
- Browser APIs: `localStorage`, Web Speech API (optional), and standard date/time APIs

No frameworks, external libraries, backend, or build step are used.

## Browser requirements

Use a modern browser with support for ES2020 JavaScript, CSS Grid, and `localStorage`. Chrome and other Chromium browsers, Firefox, and Safari provide the core app features. Speech recognition is optional and browser-dependent; in browsers that do not expose the Web Speech API, the assistant displays a support message. Some browsers restrict speech recognition and microphone access on insecure origins, so use `localhost` when running a local server.

## Run locally

1. Open the `CampusNet` folder.
2. Open `index.html` in a modern browser.
3. For microphone access or the most consistent browser behavior, serve the folder on localhost. For example, with Python installed, run `python -m http.server 8000` from the folder, then visit `http://localhost:8000`.

The stylesheet and JavaScript are linked directly from `index.html`; there is no installation or compilation step.

## Future improvements

- Export and import a backup of local workspace data.
- Add recurring sessions, calendar views, and deadline reminders.
- Offer GPA scale presets for different institutions and grading systems.
- Add richer attendance trends and a semester overview.
- Improve voice command coverage and provide optional speech playback.
- Add user-controlled session notifications and focus history.

## Voice-driven development

This application was developed during voice-driven development with Whisper Flow. Voice input was used as part of the development workflow; the optional in-app voice assistant is a separate browser feature.

## Demo workspace data

The page includes a removable demo-data module for previews and walkthroughs. Select **Load sample workspace** near the bottom of the dashboard to add sample subjects (with attendance totals), assignments (including completed and overdue examples), study sessions, and study notes. **Clear sample data** removes only records created by the demo seed function. Loading the demo again replaces the previous seeded set while preserving records you created yourself.

For a console-driven preview, the isolated module also exposes `window.CampusMateDemo.seed()` and `window.CampusMateDemo.clear()`. The module is bracketed in `app.js` with `BEGIN OPTIONAL DEMO DATA MODULE` / `END OPTIONAL DEMO DATA MODULE`; the matching demo controls are marked in `index.html`. Remove those marked blocks and the notes display markup/styles if notes are not part of the final deployment.
